#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int a = 0, b = 0;

    scanf("%d %d", &a, &b);  //  Citirea numerelor de la tastura

    printf("Suma este %d\n", a + b);  //  Afisarea sumei

    printf("Produsul este %d\n", a * b);  //  Afisarea produsului
}
