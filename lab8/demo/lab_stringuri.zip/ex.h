void ex1(char *s, char c);
void ex2(int n, char **s);
void ex3();
void ex4();
void ex5_bis(const char* str);
void ex5(const char* str);