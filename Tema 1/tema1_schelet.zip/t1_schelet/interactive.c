#include <stdio.h>
#include <stdlib.h>
#include "imageprocessing.h"
#include "bmp.h"

int main()
{
    // TODO Task 7
	
	
    return 0;
}
